@Data
@Builder
@NoArgsConstructor
public class Book {
    private String year;
    private String price;
    private String author;
    private String title;
}
